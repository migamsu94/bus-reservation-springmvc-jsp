package org.kobus.spring.service.join;

public class commonService {

}
