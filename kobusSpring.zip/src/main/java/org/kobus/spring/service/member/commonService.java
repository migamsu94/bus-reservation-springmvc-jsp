package org.kobus.spring.service.member;

public class commonService {

}
