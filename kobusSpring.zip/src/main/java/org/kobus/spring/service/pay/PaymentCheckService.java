package org.kobus.spring.service.pay;

public interface PaymentCheckService {
	
	public int getServerPrice(String prdSno);

}
