package org.kobus.spring.mapper.join;

public class commonMapper {

}
