package org.kobus.spring.mapper.board;

public class commonMapper {

}
