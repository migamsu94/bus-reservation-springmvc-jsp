package org.kobus.spring.mapper.member;

public class commonMapper {

}
