package org.kobus.spring.domain.reservation;

public class commonDTO {

}
