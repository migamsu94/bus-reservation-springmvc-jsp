package org.kobus.spring.domain.pay;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReservationPaymentDTO {
	
	private String resPayId;
	private String paymentId;
	private String resId;
	private String kusid;

}
