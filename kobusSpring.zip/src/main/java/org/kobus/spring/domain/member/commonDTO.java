package org.kobus.spring.domain.member;

public class commonDTO {

}
