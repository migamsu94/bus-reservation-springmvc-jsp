package org.kobus.spring.domain.join;

public class commonDTO {

}
