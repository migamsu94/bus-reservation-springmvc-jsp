package org.kobus.spring.domain.board;

public class commonDTO {

}
