package org.kobus.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LostCenterController {

    @GetMapping("/lossmain.do")
    public String lossCenterMain() {
        return "kobus.lossCenter/lossCenter_notice";
    }
	
    @GetMapping("/lostKumho.do")
    public String lostKumho() {
        return "kobus.lossCenter/lostKumho";
    }

    @GetMapping("/lostChunil.do")
    public String lostChunil() {
        return "kobus.lossCenter/lostChunil";
    }

    @GetMapping("/lostDongbu.do")
    public String lostDongbu() {
        return "kobus.lossCenter/lostDongbu";
    }

    @GetMapping("/lostDongyang.do")
    public String lostDongyang() {
        return "kobus.lossCenter/lostDongyang";
    }

    @GetMapping("/lostHanil.do")
    public String lostHanil() {
        return "kobus.lossCenter/lostHanil";
    }

    @GetMapping("/lostJungang.do")
    public String lostJungang() {
        return "kobus.lossCenter/lostJungang";
    }

    @GetMapping("/lostSamhwa.do")
    public String lostSamhwa() {
        return "kobus.lossCenter/lostSamhwa";
    }

    @GetMapping("/lostSokrisan.do")
    public String lostSokrisan() {
        return "kobus.lossCenter/lostSokrisan";
    }
}
